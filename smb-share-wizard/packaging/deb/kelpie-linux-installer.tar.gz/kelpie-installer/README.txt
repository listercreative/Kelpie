Kelpie 0.1.0 - Linux installer

To install:

    ./install.sh

This shows what will be installed and asks for confirmation before
touching your system. Don't run "apt install kelpie_*.deb" or
"dpkg -i" directly on the .deb in this folder - that skips the
explanation/confirmation step install.sh provides.
